#!/bin/bash

# Run the MiniZinc solver on the FoldingBike model and count solutions
minizinc --solver Gecode FoldingBike.mzn --all-solutions | awk '/----------/ {count++} END {print count}'
